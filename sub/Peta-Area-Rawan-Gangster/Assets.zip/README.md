# Project-PWA-RoutaZen
Web Apps Deteksi Area Rawan Kecelakaan Lalu Lintas di Kota Semarang
dirancang dengan menggunakan library leaflet.js
